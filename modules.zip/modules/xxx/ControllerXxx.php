<?php
namespace modules\xxx;

use application\core\Controller;
use application\core\Route;
use application\core\View;

class ControllerXxx extends Controller
{

    static function RouteMatchCheck(Route $route)
    {
        // #################################################
        $route->get('/xxx', function () {
            {
                //...
            }
            View::PageFrontendModule('xxx/home',get_defined_vars());
        });
        // #################################################
    }
}

?>