<?php

namespace modules\test\views;

use application\core\View;

class ViewTest extends View
{
    
}





