<?php
namespace modules\test\controllers;

use application\core\Controller;
use application\core\Route;
use application\core\View;

class ControllerTest extends Controller
{

    static function RouteMatchCheck(Route $route)
    {
        // #################################################
        $route->get('/test', function () {
            {
                //...
            }
            View::PageFrontendModule('test/tpls/home',get_defined_vars());
        });
        // #################################################
    }
}

?>