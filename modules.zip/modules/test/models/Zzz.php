<?php

namespace modules\test\models;

use manguto\cms7\model\Model;
use manguto\cms7\database\ModelDatabase;
use manguto\cms7\database\repository\ModelRepository;
use manguto\cms7\model\ModelAttribute;
use manguto\cms7\model\ModelSetup;

class Zzz extends Model implements ModelDatabase {
	// metodos basicos
	use ModelSetup;
	// tipo de armazenamento (Repository, Mysql, MysqlPDO, etc.)
	use ModelRepository;
	// registros base iniciais
	const default = [];
	/**
	 * Função para definicao do atributos do modelo (ModelAttribute's)
	 */
	private function defineAttributes(){
		$this->repository_directory = __DIR__ . DS . '..' . DS . 'repository' . DS;
		// ---------------------------------------------------
		$a = new ModelAttribute('nome');
		$this->SetAttribute($a);
		// ---------------------------------------------------
		$a = new ModelAttribute('idade');
		$a->setType(ModelAttribute::TYPE_INT);
		$this->SetAttribute($a);
		// ---------------------------------------------------
		$a = new ModelAttribute('peso');
		$a->setType(ModelAttribute::TYPE_FLOAT);
		$a->setUnit('Kg');
		$this->SetAttribute($a);
		// ---------------------------------------------------
	}
}
?>